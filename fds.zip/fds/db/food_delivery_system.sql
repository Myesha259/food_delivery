-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: sept 19, 2020 at 03:47 AM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.1.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `food_delivery_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `orderproduct`
--

CREATE TABLE `orderproduct` (
  `op_id` int(10) NOT NULL,
  `o_id` int(10) NOT NULL,
  `p_id` int(10) NOT NULL,
  `quantity` int(20) NOT NULL,
  `total` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET= latin1;

--
-- Dumping data for table `orderproduct`
--

INSERT INTO `orderproduct` (`op_id`, `o_id`, `p_id`, `quantity`, `total`) VALUES
(4, 15, 8, 2, 120),
(5, 16, 1, 1, 180),
(6, 16, 2, 4, 800),
(7, 16, 3, 1, 200),
(8, 16, 4, 1, 80),
(9, 1, 2, 3, 600),
(10, 1, 3, 1, 200),
(11, 1, 1, 1, 180),
(12, 1, 4, 1, 80),
(13, 2, 1, 1, 180),
(14, 2, 2, 1, 200),
(15, 2, 3, 1, 200),
(16, 2, 4, 1, 80),
(17, 3, 1, 5, 900),
(18, 3, 2, 2, 400),
(19, 3, 5, 1, 100),
(20, 4, 4, 1, 80),
(21, 4, 7, 3, 255);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `o_id` int(10) NOT NULL,
  `m_id` int(10) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`o_id`, `m_id`, `date`) VALUES
(2, 4, '2020-09-18 05:57:53'),
(3, 4, '2020-09-18 06:02:37'),
(4, 4, '2020-09-18 06:02:49');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `p_id` int(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `price` int(4) NOT NULL,
  `categories` varchar(20) NOT NULL,
  `images` varchar(100) NOT NULL,
  `available` varchar(10) NOT NULL,
  `quantity` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`p_id`, `name`, `price`, `categories`, `images`, `available`, `quantity`) VALUES
(1, 'Chicken Cheese Burger', 180, 'fastfood', 'images/chicken_cheese_burger.jpg', 'avialable', 10),
(2, 'Beef Cheese Burger', 200, 'fastfood', 'images/beef cheese burger.jpg', 'avialable', 10),
(3, 'Kacchi Biriyani', 200, 'meal', 'images/kacchi biriyani.jpg', 'avialable', 10),
(4, 'Chocolate Pastry', 80, 'desert', 'images/chocolate pastry.jpg', 'avialable', 10),
(5, 'Custard', 100, 'desert', 'images/custard.jpg', 'available ', 10),
(6, 'Ice Cream', 75, 'desert', 'images/icecream.jpeg', 'avialable', 10),
(7, 'Pastry', 85, 'desert', 'images/pastry.jpg', 'available', 10),
(8, 'Sandwich', 60, 'fastfood', 'images/sandwich.jpg', 'avialable', 10),
(9, 'Sub', 50, 'fastfood', 'images/sub.jpg', 'available', 10),
(10, 'Beef khichuri', 150, 'meal', 'images/beef khichuri.jpg', 'avialable', 10),
(11, 'Chinese Set Menu', 150, 'meal', 'images/chinese set menu.jpg', 'avialable', 10),
(12, 'Coffe', 20, 'beverage', 'images/coffe.jpg', 'available', 10),
(13, 'Tea', 20, 'beverage', 'images/tea.jpg', 'avialable', 10),
(14, 'Soft Drinks', 15, 'beverage', 'images/drinks.jpg', 'available', 10);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `name` varchar(200) NOT NULL,
  `id` varchar(10) NOT NULL,
  `m_id` int(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(11) NOT NULL,
  `password` varchar(50) NOT NULL,
  
) ENGINE=InnoDB DEFAULT CHARSET= latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`name`, `id`, `m_id`, `email`, `phone`, `password`) VALUES
-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 19, 2019 at 03:01 AM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.1.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `food_delivery_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `orderproduct`
--

CREATE TABLE `orderproduct` (
  `op_id` int(10) NOT NULL,
  `o_id` int(10) NOT NULL,
  `p_id` int(10) NOT NULL,
  `quantity` int(20) NOT NULL,
  `total` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orderproduct`
--

INSERT INTO `orderproduct` (`op_id`, `o_id`, `p_id`, `quantity`, `total`) VALUES
(4, 15, 8, 2, 120),
(5, 16, 1, 1, 180),
(6, 16, 2, 4, 800),
(7, 16, 3, 1, 200),
(8, 16, 4, 1, 80),
(9, 1, 2, 3, 600),
(10, 1, 3, 1, 200),
(11, 1, 1, 1, 180),
(12, 1, 4, 1, 80),
(13, 2, 1, 1, 180),
(14, 2, 2, 1, 200),
(15, 2, 3, 1, 200),
(16, 2, 4, 1, 80),
(17, 3, 1, 5, 900),
(18, 3, 2, 2, 400),
(19, 3, 5, 1, 100),
(20, 4, 4, 1, 80),
(21, 4, 7, 3, 255);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `o_id` int(10) NOT NULL,
  `m_id` int(10) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`o_id`, `m_id`, `date`) VALUES
(2, 4, '2019-08-19 05:57:53'),
(3, 4, '2019-08-19 06:02:37'),
(4, 4, '2019-08-19 06:02:49');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `p_id` int(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `price` int(4) NOT NULL,
  `categories` varchar(20) NOT NULL,
  `images` varchar(100) NOT NULL,
  `available` varchar(10) NOT NULL,
  `quantity` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`p_id`, `name`, `price`, `categories`, `images`, `available`, `quantity`) VALUES
(1, 'Chicken Cheese Burger', 180, 'fastfood', 'images/chicken_cheese_burger.jpg', 'avialable', 10),
(2, 'Beef Cheese Burger', 200, 'fastfood', 'images/beef cheese burger.jpg', 'avialable', 10),
(3, 'Kacchi Biriyani', 200, 'meal', 'images/kacchi biriyani.jpg', 'avialable', 10),
(4, 'Chocolate Pastry', 80, 'desert', 'images/chocolate pastry.jpg', 'avialable', 10),
(5, 'Custard', 100, 'desert', 'images/custard.jpg', 'available ', 10),
(6, 'Ice Cream', 75, 'desert', 'images/icecream.jpeg', 'avialable', 10),
(7, 'Pastry', 85, 'desert', 'images/pastry.jpg', 'available', 10),
(8, 'Sandwich', 60, 'fastfood', 'images/sandwich.jpg', 'avialable', 10),
(9, 'Sub', 50, 'fastfood', 'images/sub.jpg', 'available', 10),
(10, 'Beef khichuri', 150, 'meal', 'images/beef khichuri.jpg', 'avialable', 10),
(11, 'Chinese Set Menu', 150, 'meal', 'images/chinese set menu.jpg', 'avialable', 10),
(12, 'Coffe', 20, 'beverage', 'images/coffe.jpg', 'available', 10),
(13, 'Tea', 20, 'beverage', 'images/tea.jpg', 'avialable', 10),
(14, 'Soft Drinks', 15, 'beverage', 'images/drinks.jpg', 'available', 10);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `name` varchar(200) NOT NULL,
  `id` varchar(10) NOT NULL,
  `m_id` int(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(11) NOT NULL,
  `password` varchar(50) NOT NULL
  
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`name`, `id`, `m_id`, `email`, `phone`, `password`) VALUES
('shatu', 'abc', 1, 'shanzu@gmail.com', '016214567891',  '12345'),
('myesha', 'asd', 4, 'myesha@gmail.com', '01400288032', '56789' );

--
-- Indexes for dumped tables
--

--
-- Indexes for table `orderproduct`
--
ALTER TABLE `orderproduct`
  ADD PRIMARY KEY (`op_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`o_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`p_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`m_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `orderproduct`
--
ALTER TABLE `orderproduct`
  MODIFY `op_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `o_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `p_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `m_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orderproduct`
--
ALTER TABLE `orderproduct`
  ADD CONSTRAINT `fk` FOREIGN KEY (`o_id`) REFERENCES `orders` (`o_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `orderproduct`
--
ALTER TABLE `orderproduct`
  ADD PRIMARY KEY (`op_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`o_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`p_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`m_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `orderproduct`
--
ALTER TABLE `orderproduct`
  MODIFY `op_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `o_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `p_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `m_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orderproduct`
--
ALTER TABLE `orderproduct`
  ADD CONSTRAINT `fk` FOREIGN KEY (`o_id`) REFERENCES `orders` (`o_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
